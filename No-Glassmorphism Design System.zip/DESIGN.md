# Project design rules

## STRICT NO-GLASSMORPHISM (hard constraint, overrides any "modern UI" convention)
Never use: `backdrop-filter: blur()`, frosted glass, translucent panels, semi-transparent
floating cards, blurred backgrounds, glass nav/modals/sidebars/dropdowns, glowing translucent
surfaces, excessive transparency, gradient glass surfaces.

## Surfaces — solid and opaque
- Page background: `#0B0D0F`
- Primary surface: `#111418`
- Secondary surface: `#171B20`
- Elevated surface: `#1C2127`
- Border: `#252B32`

Every major surface: `background: #111418; border: 1px solid #252B32;` — never `rgba()` + blur.

- Modals: fully opaque surface. Overlay backdrop may be dark opaque/semi-opaque, modal itself never.
- Sidebars: solid `#111418`, `border-right: 1px solid #252B32`.
- Dropdowns: solid `#171B20` + `1px solid #252B32`.
- Cards: solid bg, thin border, compact padding, subtle hover border change. No huge shadows,
  no gradient cards.

## Depth comes from
Solid color hierarchy, borders, spacing, typography, alignment, subtle shadows where
appropriate, accent indicators, hover/active states — NOT transparency, blur, glow, gradients.

## Test
The UI must still look premium with ALL blur, transparency, gradients and shadows removed.
Identity: "precision engineering tool", not "glassmorphism SaaS landing page".
